# 👋 Hello there! Welcome. Please follow the steps below to tell us about your contribution

1. Copy the correct template for your contribution

    - 🐛 Are you reporting a bug? Here is yours [template](./.github/ISSUE_TEMPLATE/bug_report.md)
    - 📝 Are you have an idea for the project? Here is yours [template](./.github/ISSUE_TEMPLATE/feature_request.md)

1. Replace this text with the contents of the template
1. Fill in all sections of the template
1. Click "Create pull request"
